package main

import "fmt"

// Exercice 1: Hello World
func main() {
	fmt.Println("Exercice 1 — Hello, Go!")
}
